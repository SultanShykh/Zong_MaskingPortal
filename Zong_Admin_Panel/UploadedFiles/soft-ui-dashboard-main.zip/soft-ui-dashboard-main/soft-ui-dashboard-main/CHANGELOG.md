# Change Log

## [1.0.0] 2021-04-02
### Original Release

## [1.0.1] 2021-04-06
### Improvements
- Design changes

## [1.0.2] 2021-05-10
### Updates & Bugfixing
- upgrade Bootstrap version to v5.0.0
- bug fixing
